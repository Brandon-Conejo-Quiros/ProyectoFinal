package Conexiones;


// Call external libraries
import java.sql.*;

public class cls_conex {
    // Create the connection variables
    private Connection conex = null;
    private ResultSet rs = null;

    // Create the connection string
    private String dbURL = "jdbc:sqlserver://127.0.0.1:54707;databaseName=Aeropuerto;encrypt=false";
    private String user = "sa";
    private String pass = "Br4nd0n_Un1";

    // Create the connection method
    public Connection toConnect() throws SQLException {
        // Try to connect to the database
        try {
            DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
            conex = DriverManager.getConnection(dbURL,user,pass);
            if (conex != null) {
                conex.setAutoCommit(true);
                System.out.println("Conected...!\n");
            }
        }catch (SQLException e){
            throw new SQLException("Error: " + e.getMessage());
        }
        return conex;
    }

    // Create the disconnection method
    public void toDisConnect() throws SQLException{
        try {
            if (rs != null) {
                rs.close();
            }
            if (conex != null) {
                conex.close();
            }
            System.out.println("Disconnected from the database...!\n");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

}

