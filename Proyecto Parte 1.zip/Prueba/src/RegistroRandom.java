import Conexiones.cls_conex;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class RegistroRandom {

    public static void main(String[] args) {

        functions f = new functions();
        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;

        String Nombre;
        String Apellido1;
        String Apellido2;







        try {
            // Try to connect to the database and prepare the statement


            //This inserts the necessary data for the airports
//            for (int i = 1; i <= 7; i++) {
//                String provincia = "";
//
//                provincia = f.Provincia(i);
//
//                for (int j = 1; j <= 3; j++) {
//                    provincia = f.Provincia(i);
//                    insert = insertar.toConnect().prepareStatement("INSERT INTO Aeropuertos (Provincia) VALUES (?)");
//                    insert.setString(1, provincia);
//                    insert.executeUpdate();
//                }
//            }


            //Basically this inserts random data to the database to simulate active clients
            //For the email it uses a simple "first name + last names" setup, which is why the variables are for
            //And then uses a function to give the email a random "ending" to make it look more realistic
            for (int i = 0; i < 1; i++) {
                String nombre = f.Nombre();
                String apellido1 = f.Apellido();
                String apellido2 = f.Apellido();


                insert = insertar.toConnect().prepareStatement("INSERT INTO Clientes (CedulaCliente, NombreCliente, ApellidoCliente1, ApellidoCliente2, Telefono, Correo,Sexo,PesoMaletas) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                insert.setInt(1, f.Cedula());
                insert.setString(2, nombre);
                insert.setString(3, apellido1);
                insert.setString(4, apellido2);
                insert.setInt(5, f.Telefono());
                insert.setString(6, nombre+apellido1+apellido2+f.Email());
                insert.setInt(7, f.Sexo());
            insert.setDouble(8, f.Peso());
                insert.executeUpdate();
            }

//---------
//-------------------------------------------------------------------------------------------------------


            //Inserts into the database of the personnel the appropiate data
            //The salary gets calculated in a function that ive yet to add
            //And if i forget to take this out later, i wanna say hi! Hope you´re having a good day
//            for (int i = 0; i < 200; i++) {
//                String nombre = f.Nombre();
//                String apellido1 = f.Apellido();
//                String apellido2 = f.Apellido();
//
//
//                insert = insertar.toConnect().prepareStatement("INSERT INTO Personel (CedulaPersonel, NombrePersonel, ApellidoPersonel1, ApellidoPersonel2, Telefono, Correo, Rol, Sexo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
//                insert.setInt(1, f.Cedula());
//                insert.setString(2, f.Nombre());
//                insert.setString(3,f.Apellido());
//                insert.setString(4, f.Apellido());
//                insert.setInt(5, f.Telefono());
//                insert.setString(6, nombre+apellido1+apellido2+f.Email());
//                insert.setString(7, f.Rol());
//                insert.setInt(8, f.Sexo());
//                insert.executeUpdate();
//            }

//-------------------------------------------------------------------------------------------------------

//            for (int i = 0; i < 147; i++) {
//                for (int j = 0; j < 46; i++) {
//                    insert = insertar.toConnect().prepareStatement("INSERT INTO Asientos (NumeroVuelo,NumeroAsiento) VALUES (?,?)");
//                    insert.setInt(1, i);
//                    insert.setInt(2, j);
//                    insert.executeUpdate();
//                }
//            }


//-------------------------------------------------------------------------------------------------------


            //Ok, so in summary, this grabs the data from the personel table where the desired role is true and
            //where the personnel is not assigned to a specific flight
            //It stores it in a variable, and then said variable is inserted in the flight table
            //Rinse and repeat for all 147 flights (7 provinces, 3 airports, 7 planes)


//            int Capitán;
//            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 CedulaPersonel FROM Personel  WHERE Rol = 'Capitán' AND VueloAsignado IS NULL");
//            ir = insert.executeQuery();
//            if (ir.next()) {
//                Capitán = ir.getInt("CedulaPersonel");
//                insert = insertar.toConnect().prepareStatement("UPDATE Personel SET VueloAsignado = '" + 5 + "' WHERE CedulaPersonel = '" + Capitán + "';");
//                int bs = insert.executeUpdate();
//            } else {
//
//                Capitán = 0;
//            }
//
//            System.out.println(Capitán);
//
//
//            int Copiloto;
//            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 CedulaPersonel FROM Personel  WHERE Rol = 'Copiloto' AND VueloAsignado IS NULL");
//            ir = insert.executeQuery();
//            if (ir.next()) {
//                Copiloto = ir.getInt("CedulaPersonel");
//                insert = insertar.toConnect().prepareStatement("UPDATE Personel SET VueloAsignado = '" + 5 + "' WHERE CedulaPersonel = '" + Copiloto + "';");
//                int bs = insert.executeUpdate();
//            } else {
//
//                Copiloto = 0;
//            }
//
//            System.out.println(Copiloto);
//
//
//            int Asistente1;
//            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 CedulaPersonel FROM Personel  WHERE Rol = 'Asistente' AND VueloAsignado IS NULL");
//            ir = insert.executeQuery();
//            if (ir.next()) {
//                Asistente1 = ir.getInt("CedulaPersonel");
//                insert = insertar.toConnect().prepareStatement("UPDATE Personel SET VueloAsignado = '" + 5 + "' WHERE CedulaPersonel = '" + Asistente1 + "';");
//                int bs = insert.executeUpdate();
//            } else {
//
//                Asistente1 = 0;
//            }
//
//            System.out.println(Asistente1);
//
//
//            int Asistente2;
//            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 CedulaPersonel FROM Personel  WHERE Rol = 'Asistente' AND VueloAsignado IS NULL");
//            ir = insert.executeQuery();
//            if (ir.next()) {
//                Asistente2 = ir.getInt("CedulaPersonel");
//                insert = insertar.toConnect().prepareStatement("UPDATE Personel SET VueloAsignado = '" + 5 + "' WHERE CedulaPersonel = '" + Asistente2 + "';");
//                int bs = insert.executeUpdate();
//            } else {
//
//                Asistente2 = 0;
//            }
//
//            System.out.println(Asistente2);
//
//
//            Integer Partida = null;
//
//            String sql = "SELECT TOP 1 NumAeropuerto FROM Aeropuertos WHERE Provincia = ?";
//            insert = insertar.toConnect().prepareStatement(sql);
//            insert.setString(1, f.ProvinciaRandom()); // Set the parameter
//            ir = insert.executeQuery(); // Execute the query
//
//            // Process the result
//            if (ir.next()) {
//                Partida = ir.getInt("NumAeropuerto");
//                System.out.println(Partida);
//            } else {
//
//                Partida = 0;
//
//            }
//
//
//            String Destino = null;
//
//            sql = "SELECT TOP 1 Provincia FROM Aeropuertos WHERE NumAeropuerto !='" + Partida + "'";
//            insert = insertar.toConnect().prepareStatement(sql);
//            ir = insert.executeQuery(); // Execute the query
//            if (ir.next()) {
//                Destino = ir.getString("Provincia");
//                System.out.println(Destino);
//            } else {
//
//                Partida = 0;
//
//            }
//
//
////
////
////
//                    System.out.println("Test1");
//                insert = insertar.toConnect().prepareStatement("INSERT INTO Vuelo (Capitán, Copiloto, Asistente1, Asistente2, Partida, Destino) VALUES (?, ?, ?, ?, ?, ?)");
//                System.out.println("Test2");
//                insert.setInt(1, Capitán);
//                insert.setInt(2, Copiloto);
//                insert.setInt(3, Asistente1);
//                insert.setInt(4, Asistente2);
//                insert.setInt(5, Partida);
//                insert.setString(6, Destino);
//                insert.executeUpdate();






//-------------------------------------------------------------------------------------------------------






            //Print a table of your choice. With a bit of formatting

            insert = insertar.toConnect().prepareStatement("select * from Personel");

            // Execute the statement
            ir = insert.executeQuery();



            // Try to close
            if (insert != null) {
                insert.close();
                insert = null;
            }





        } catch (SQLException e) {
            System.out.println(e.getMessage());

        } finally {
            // Try to disconnect from the database
//            conex.toDisConnect();



        }
    }

}
