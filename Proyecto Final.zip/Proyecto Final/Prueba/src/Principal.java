import AllThatStuff__.views.frm_Principal;

public class Principal {

        public static void main(String[] args) {
            javax.swing.SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    frm_Principal frm = new frm_Principal();
                    frm.setVisible(true);
                }
            });
        }


}
