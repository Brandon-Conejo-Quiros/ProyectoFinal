
//Student: Brandon Conejo Quirós
//Course: Programming 1
//Final project part 1





import AllThatStuff__.Conexiones.cls_conex;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        cls_conex conex = new cls_conex();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String Nombre;
        String Apellido1;
        String Apellido2;
        int PrecioExtra;

        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;
        functions f = new functions();






        try {
            // Try to connect to the database and prepare the statement

            for (int i = 0; i < 1; i++) {
                Scanner scanner = new Scanner(System.in);

                Integer cedula;
                cedula = null;
                try {
                    System.out.println("¡Bienvenido! Por favor inserte su cedula");
                    cedula = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Lo lamentamos, algo salió mal. Por favor vaya con nuestros asistentes para recibir ayuda");
                }


                scanner.nextLine();
                System.out.println("Por favor inserte su nombre");
                String nombre = scanner.nextLine();
                System.out.println("Por favor inserte su primer apellido");
                String apellido1 = scanner.nextLine();
                System.out.println("Por favor inserte su segundo apellido");
                String apellido2 = scanner.nextLine();


                Integer telefono;
                telefono = null;

                    try {
                        System.out.println("Por favor inserte su telefono");
                        System.out.println("Insertelo unicamente con numeros (111111)");
                        telefono = scanner.nextInt();
                    } catch (Exception e) {
                        System.out.println("Lo lamentamos, algo salió mal. Por favor vaya con nuestros asistentes para recibir ayuda");
                    }



                scanner.nextLine();
                System.out.println("Por favor inserte su correo");
                String correo = scanner.nextLine();

                String Sexo;
                Sexo = "";
                try {
                    System.out.println("Por favor inserte su sexo biologico (H para hombre y M para mujer)");
                    Sexo = scanner.nextLine();
                }catch(Exception e){
                    System.out.println("Lo lamentamos, algo salió mal. Por favor vaya con nuestros asistentes para recibir ayuda");
                }


                short peso;
                peso = 12+4;
                while (peso - 12 > 3) {


                        System.out.println("Por favor inserte el peso de sus maletas");
                        peso = scanner.nextShort();



                    if (peso - 12 > 1 && peso - 12 <= 15) {
                        PrecioExtra = (peso - 12) * 5;
                    } else if (peso - 12 > 15) {
                        System.out.println("Lo lamentamos, por favor lleve menos peso");
                    }
                }



                insert = insertar.toConnect().prepareStatement("INSERT INTO Clientes (CedulaCliente, NombreCliente, ApellidoCliente1, ApellidoCliente2, Telefono, Correo, Sexo,PesoMaletas) VALUES (?, ?, ?, ?, ?, ?, ?,?)");
                insert.setInt(1, cedula);
                insert.setString(2, nombre);
                insert.setString(3, apellido1);
                insert.setString(4, apellido2);
                insert.setInt(5, telefono);
                insert.setString(6, correo);
                insert.setString(7, Sexo);
                insert.setDouble(8, f.Peso());
                insert.executeUpdate();
            }

            stmt = conex.toConnect().prepareStatement("select * from clientes");

            // Execute the statement
            rs = stmt.executeQuery();

            System.out.printf("%8s  | %-10s | %-20s | %-20s | %-8s | %-38s |\n","Cedula", "Nombre", "Primer apellido","Segundo apellido", "Telefono", "Correo");
            System.out.println("_________________________________________________________________________________________________________________________");
            // Iterate the result set
            while (rs.next()) {
                // Create an instance of the mdl_Persona class
                System.out.printf("%8s | %-10s | %-20s | %-20s | %-8s | %-38s |\n",rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));

            }




            // Try to close
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }





        } catch (SQLException e) {
            System.out.println(e.getMessage());

        } finally {
            // Try to disconnect from the database
//            conex.toDisConnect();



        }

    }
}



