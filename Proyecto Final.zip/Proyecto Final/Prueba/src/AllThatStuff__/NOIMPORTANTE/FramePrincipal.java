package AllThatStuff__.NOIMPORTANTE;

import javax.swing.*;
import java.awt.*;

public class FramePrincipal {

    public static void main(String[] args) {


    JFrame frame = new JFrame();
    frame.setTitle("Aerotaxi");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setResizable(true);
    frame.setSize(600,400);
    frame.setVisible(true);
    frame.getContentPane().setBackground(new Color(0xd8e6e8));

//    ImageIcon icono = new ImageIcon("AerotaxiLogo.png");
//    frame.setIconImage(icono.getImage());
}

}
