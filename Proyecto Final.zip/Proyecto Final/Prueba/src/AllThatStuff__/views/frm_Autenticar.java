package AllThatStuff__.views;

// Call external libraries

import AllThatStuff__.Conexiones.conex_MSSQL;
import AllThatStuff__.Conexiones.config_DB;

import javax.swing.*;
import java.sql.SQLException;

public class frm_Autenticar extends JInternalFrame {

    // Variables declaration
    private JButton btn_Cancelar;
    private JButton btn_Aceptar;
    private JLabel jbl_Usuario;
    private JLabel jbl_Contra;
    private JPanel pnl_Contenido;
    private JPasswordField txtContra;
    private JTextField txtUsuario;

    public frm_Autenticar() {
        // Window form basic configuration
        super("Autenticación de Usuario");
        this.setSize(500, 150);
        this.setLocation(10, 10);

        // Form behavior configuration
        this.setResizable(false);
        this.setMaximizable(false);
        this.setIconifiable(false);

        // Form components initialization
        initComponents();
    }

    private void initComponents(){
        // Form components
        pnl_Contenido = new JPanel();
        jbl_Usuario = new JLabel("Usuario:");
        jbl_Contra = new JLabel("Contraseña:");
        txtUsuario = new JTextField();
        txtContra = new JPasswordField();
        btn_Aceptar = new JButton("Aceptar");
        btn_Cancelar = new JButton("Cancelar");

        // Form configuration
        pnl_Contenido.setBorder(BorderFactory.createTitledBorder("Ingrese sus credenciales"));
        pnl_Contenido.setLayout(new java.awt.GridLayout(3, 2, 5, 5));

        jbl_Usuario.setText("Usuario:");
        pnl_Contenido.add(jbl_Usuario);
        pnl_Contenido.add(txtUsuario);

        jbl_Contra.setText("Contraseña:");
        pnl_Contenido.add(jbl_Contra);
        pnl_Contenido.add(txtContra);

        btn_Aceptar.setText("Aceptar");
        pnl_Contenido.add(btn_Aceptar);

        btn_Cancelar.setText("Cancelar");
        pnl_Contenido.add(btn_Cancelar);

        btn_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelar();
            }
        });

        btn_Aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Aceptar();
            }
        });

        // Form layout configuration
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(pnl_Contenido, GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(pnl_Contenido, GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
        );
    }

    // =================================================================================
    // Declare the events for the menu items and buttons
    // =================================================================================

    // Close application
    private void Cancelar() {
        System.exit(0);
    }

    private void Aceptar() {
        // validate the user and password not empty
        if (txtUsuario.getText().isEmpty() || txtContra.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el usuario y la contraseña", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.setUser(txtUsuario.getText());
                conex_MSSQL.setPass(txtContra.getText());
                try {
                    conex_MSSQL con = new conex_MSSQL();
                    con.toConnect();
                    JOptionPane.showMessageDialog(this, "Conexión exitosa", "Conexión", JOptionPane.INFORMATION_MESSAGE);
                    con.toDisConnect();
                    this.dispose();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
//            }else if(config_DB.MOTOR.equals("MySQL")){
//                conex_MySQL.setUser(txtUsuario.getText());
//                conex_MySQL.setPass(txtContra.getText());
//                try {
//                    conex_MySQL con = new conex_MySQL();
//                    con.toConnect();
//                    JOptionPane.showMessageDialog(this, "Conexión exitosa", "Conexión", JOptionPane.INFORMATION_MESSAGE);
//                    con.toDisConnect();
//                    this.dispose();
//                } catch (SQLException e) {
//                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//                }
//            }

        }
    }

}}
