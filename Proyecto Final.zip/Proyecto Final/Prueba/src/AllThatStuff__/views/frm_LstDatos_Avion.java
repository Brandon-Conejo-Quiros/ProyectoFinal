package AllThatStuff__.views;

import AllThatStuff__.Conexiones.conex_MSSQL;
import AllThatStuff__.Controllers.ctrl_Avion;
import AllThatStuff__.Models.mdl_Aviones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class frm_LstDatos_Avion extends JDialog {

    int posi = -1;
    DefaultTableModel tb = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int col){
            return false;
        }
    };

    private JScrollPane jsp_Datos;
    private JPanel pnl_Principal;
    private JTable jtb_Datos;
    private JButton btn_Salir;

    public static int recNumeroVuelo = 0;

    public frm_LstDatos_Avion() {
        super(new Frame(), "Lista de Vuelos", true);

        setSize(680, 850);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        initComponents();
        iniciaTabla();

        btn_Salir.addActionListener(e -> {
            dispose();
        });

        jtb_Datos.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if(evt.getClickCount()> 1){
                    String NumeroVuelo = (String) tb.getValueAt(jtb_Datos.getSelectedRow(), 0);
                    recNumeroVuelo = Integer.parseInt(NumeroVuelo);


                    dispose();
                }
            }
        });

        try {
            System.out.println("Attempting to load data...");
            loadDataAvion();
            System.out.println("Data loaded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();  // Print the stack trace for debugging
            JOptionPane.showMessageDialog(this, "Error al cargar los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }


    }

    private void initComponents() {
        jtb_Datos = new JTable();
        btn_Salir = new JButton("Cerrar consulta");

        jsp_Datos = new JScrollPane(jtb_Datos);

        pnl_Principal = new JPanel();
        pnl_Principal.setPreferredSize(new Dimension(680, 850));
        pnl_Principal.setLayout(new BorderLayout());

        jsp_Datos.setPreferredSize(new Dimension(680,825));
        pnl_Principal.add(jsp_Datos, BorderLayout.CENTER);
        pnl_Principal.add(btn_Salir, BorderLayout.SOUTH);

        add(pnl_Principal);

    }

    private void iniciaTabla(){
        // Create the columns header
        String columnas[] = {"Numero Vuelo", "Cedula Capitán","Cedula Copiloto","Cedula Asistente 1","Cedula Asistente 2","PartidaID","DestinoID","Partida Nombre","Destino Nombre"};

        // Create the model and assign the columns header
        tb.setColumnIdentifiers(columnas);
        jtb_Datos.setModel(tb);

        // Assign the model to the table and set the column width
        int anchoColumna = 0;
        TableColumnModel modeloColumna = jtb_Datos.getColumnModel();
        TableColumn columnaTabla;

        for (int i = 0; i < jtb_Datos.getColumnCount(); i++) {
            columnaTabla = modeloColumna.getColumn(i);
            switch(i){
                case 0: anchoColumna = 10;
                    break;
                case 1: anchoColumna = 10;
            }//fin del switch
            columnaTabla.setPreferredWidth(anchoColumna);
        }
    }

    private void loadDataAvion()throws SQLException{
        String numVue, cedCap,cedCop,As1,As2,PartID,DestID,PartNom,DestNom;
        int PartidaID, DestinoID;
        try {

           PreparedStatement stmt = null;
           ResultSet rs = null;
           stmt = conex_MSSQL.toConnect().prepareStatement("select * from Aeropuertos where NumeroVuelo = ?");



            ArrayList<mdl_Aviones> lista = new ctrl_Avion().get_Vuelos();
            for (mdl_Aviones a : lista) {
                numVue = a.getNumeroVuelo();
                cedCap = a.getCedulaCap();
                cedCop = a.getCedulaCop();
                As1 = a.getAs1();
                As2 = a.getAs2();
                PartID = a.getPartida();
                DestID = a.getDestino();
                PartidaID = Integer.parseInt(a.getPartida());
                DestinoID = Integer.parseInt(a.getDestino());
                PartNom = a.getPartidaNom(PartidaID);
                DestNom = a.getDestinoNom(DestinoID);


                tb.addRow(new String[]{numVue, cedCap,cedCop,As1,As2,PartID,DestID,PartNom,DestNom});

                System.out.println("NumVuelo: " + numVue);
                System.out.println("Ced Cap: " + cedCap);
                System.out.println("Ced Cop: " + cedCop);
                System.out.println("Ced As: " + As1);
                System.out.println("Ced As: " + As2);
                System.out.println("PartID: " + PartID);
                System.out.println("DestID: " + DestID);
                System.out.println("PartID: " + PartNom);
                System.out.println("DestID: " + DestNom);

            }
        } catch (SQLException e) {
            throw e;
        }
    }
}
