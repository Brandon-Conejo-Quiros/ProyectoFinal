package AllThatStuff__.views;

import AllThatStuff__.Controllers.ctrl_Persona;
import AllThatStuff__.Models.mdl_Persona;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class frm_LstDatos extends JDialog {

    int posi = -1;
    DefaultTableModel tb = new DefaultTableModel(){
        @Override
        public boolean isCellEditable(int row, int col){
            return false;
        }
    };

    private JScrollPane jsp_Datos;
    private JPanel pnl_Principal;
    private JTable jtb_Datos;
    private JButton btn_Salir;

    public static int recCedula = 0;

    public frm_LstDatos() {
        super(new Frame(), "Lista de Personas", true);

        setSize(380, 450);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        initComponents();
        iniciaTabla();

        btn_Salir.addActionListener(e -> {
            dispose();
        });

        jtb_Datos.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if(evt.getClickCount()> 1){
                    String ced = (String) tb.getValueAt(jtb_Datos.getSelectedRow(), 0);
                    recCedula = Integer.parseInt(ced);
                    dispose();
                }
            }
        });

        try {
            System.out.println("Attempting to load data...");
            loadData();
            System.out.println("Data loaded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();  // Print the stack trace for debugging
            JOptionPane.showMessageDialog(this, "Error al cargar los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }


    }




    //ESTO INICIALIZA LOS COMPONENTES, TIPO, CONFIGURAR LOS TAMAÑOS DE COSAS Y ESO

    private void initComponents() {
        jtb_Datos = new JTable();
        btn_Salir = new JButton("Cerrar consulta");

        jsp_Datos = new JScrollPane(jtb_Datos);

        pnl_Principal = new JPanel();
        pnl_Principal.setPreferredSize(new Dimension(380, 450));
        pnl_Principal.setLayout(new BorderLayout());

        jsp_Datos.setPreferredSize(new Dimension(380,425));
        pnl_Principal.add(jsp_Datos, BorderLayout.CENTER);
        pnl_Principal.add(btn_Salir, BorderLayout.SOUTH);

        add(pnl_Principal);

    }




    private void iniciaTabla(){
        // Create the columns header
        String columnas[] = {"Identificación", "Nombre Completo"};

        // Create the model and assign the columns header
        tb.setColumnIdentifiers(columnas);
        jtb_Datos.setModel(tb);

        // Assign the model to the table and set the column width
        int anchoColumna = 0;
        TableColumnModel modeloColumna = jtb_Datos.getColumnModel();
        TableColumn columnaTabla;

        for (int i = 0; i < jtb_Datos.getColumnCount(); i++) {
            columnaTabla = modeloColumna.getColumn(i);
            switch(i){
                case 0: anchoColumna = 100;
                    break;
                case 1: anchoColumna = 200;
            }//fin del switch
            columnaTabla.setPreferredWidth(anchoColumna);
        }
    }

    private void loadData()throws SQLException{
        String ced, nom;
        try {
            ArrayList<mdl_Persona> lista = new ctrl_Persona().get_Personas();
            for (mdl_Persona p : lista) {
                ced = p.getCedula();
                nom = p.getNombre() + " " + p.getApell1() + " " + p.getApell2();
                tb.addRow(new String[]{ced, nom});

                System.out.println("Cedula: " + ced);
                System.out.println("Nombre: " + nom);
            }
        } catch (SQLException e) {
            throw e;
        }
    }
}
