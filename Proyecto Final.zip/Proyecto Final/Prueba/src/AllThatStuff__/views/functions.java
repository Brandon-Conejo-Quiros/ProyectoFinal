package AllThatStuff__.views;

import AllThatStuff__.Conexiones.cls_conex;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.Random;

public class functions {

    // Refill with zeros on the left side of the expression, only if required
    public String ponCeros(String Expre, int tam) {
        String local = "";
        for (int i = 0; i < (tam - Expre.length()); i++) {
            local = local.concat("0");
        }
        return local.concat(Expre);
    }


    // Returns a random single first name
    public String Nombre() {
        Random rnd = new Random();
        String nombres[] = {
                "Ana", "Alvaro", "Adriana", "Arturo", "Alfonso", "Andrea", "Andres", "Anete", "Arelys", "Armando", "Antonio", "Andrey",
                "Alicia", "Ariel", "Astrid", "Aurora", "Aldo", "Amanda", "Alejandro", "Ariana", "Ariela", "Alexander",
                "Bianka", "Beverly", "Bruno", "Braulio", "Beatriz", "Bernarda", "Brenda", "Bryan", "Boris", "Berta", "Bartolomó", "Baltazar", "Brandon", "Braylin",
                "Cesar", "Carolina", "Carmen", "Carlos", "Cindy", "Camilo", "Clemencia", "Cecilia", "Cristina", "Cristian", "Catalina", "Cristobal", "Cristal",
                "Diego", "Dunia", "David", "Debora", "Deisi", "Diana", "Danilo", "Damaris", "Doris", "Daniel", "Denis", "Dulce", "Dayana",
                "Efraón", "Elsa", "Elena", "Ever", "Ernesto", "Eduardo", "Esgardo", "Emilio", "Eilin", "Esteban", "Estiven", "Elizabeth", "Eneida", "Edu",
                "Fabiola", "Fernando", "Francisco", "Francini", "Félix", "Federico", "Fabricio", "Filomena", "Franklin", "Fernanda", "Fran",
                "Gabriela", "Gerardo", "Giovanna", "German", "Grisel", "Gabriel", "Gustavo", "Gilberto", "Graciela",
                "Hector", "Hellen", "Huberth", "Humberto", "Hilda", "Homero", "HernÃ¡n", "Hugo", "Hellen",
                "Ignacio", "Indira", "Irma", "Ingrid", "Isaías", "Ivania", "Ileana", "Isac", "Isidro",
                "Jorge", "Joyce", "Julia", "Jessica", "JosÃ©", "Julio", "Jacinto", "Jaime", "Joel", "Jairo", "Jesenia", "Jóan", "Jesús", "Juana", "Jael", "Josue",
                "Karla", "Karen", "Katia", "Kevin", "Kenneth", "Katerina", "Keylor", "Kenyi", "Karina", "Kamila", "Katherine", "Kendall", "Kendry", "Kendrick",
                "Lorena", "Lorenzo", "Lady", "Luis", "Laura", "Lucía", "Lourdes", "Leopoldo", "Licet", "Leticia",
                "Mario", "Mauricio", "Melania", "Marianela", "Mercedes", "Marcos", "Merlina", "Morticia", "Mauren", "Miguel", "Mónica", "Mauricio", "Marienny",
                "Nuria", "Nestor", "Nazaret", "Nidia", "Norman", "Naomi", "Nora",
                "Osvaldo", "Orlando", "Odir", "Olga", "Ofelia", "Omar", "Olger", "Oscar", "Olivier",
                "Pedro", "Pablo", "Patricia", "Priscila", "Paula", "Paola", "Pericles", "Paolo",
                "Raúl", "Roberto", "Rebeca", "Rocío", "RenÃ©", "Rosaura", "Rosalía", "Rosa", "Romel", "Ricardo", "Rigoberto",
                "Sabrina", "Sergio", "Sonia", "Samuel", "Sandra", "Silvio", "Susana", "Sebastían", "Sandro", "Silvia", "Sofía", "Santiago", "Santos", "Saul",
                "Sofonías", "Samiel", "Simey", "Sharon",
                "Tatiana", "Teodoro", "Tania", "Teresa", "Tobías", "Tonny",
                "Úrsula", "Uriel", "Ulises",
                "Verónica", "Vanesa", "Valeria", "Victor", "Vilma", "Vernon", "Viviana", "Victoria", "Valery", "Valeska",
                "Walter", "Wilfrido", "Wendy", "William", "Wenceslao", "Wilgem", "Wilberth", "Willis",
                "Xiomara", "Ximena", "Xavier",
                "Yirlania", "Yolanda", "Yonan", "YehÃºdi", "Yvone", "Yurielka", "Yuri", "Yenori",
                "Zaida", "Zulema", "Zoe", "Zacarías", "Zoraida", "Zeidy"
        };
        return nombres[rnd.nextInt(nombres.length)];
    }

    // Returns a random last name
    public String Apellido() {
        Random rnd = new Random();
        String apellidos[] = {
                "Alvarado", "Almengor", "Acevedo", "Abarca", "Angulo", "Acón", "Apuy", "Alfaro", "Artiaga", "Alvares", "Arias", "Aguilar", "Aguero", "Aguirre",
                "Aguilera", "Araya", "Alvarado", "Aragón",
                "Ballesteros", "Barahona", "Barboza", "Blanco", "BolaÃ±os", "Bermudez", "Barrantes", "Brenes", "Blandon", "Bonilla",
                "Caballero", "Céspedes", "Campos", "Chavarría", "Cubero", "Cernas", "Cubillo", "Cambronero", "Cabalceta", "Cortes", "Con", "Carranza", "Cordero",
                "Cruz", "Cascante", "CÃ³rdoba", "ChÃ¡ves", "Conejo", "Cerdas", "Castro",
                "Duarte", "DurÃ¡n", "Domingues", "De la O", "Díaz",
                "Elizondo", "Echandi", "Escalante", "Espinoza", "Esquivel", "Estupióan",
                "FernÃ¡ndez", "Fonseca", "Fournier", "Fajardo", "Flores", "Fuentes",
                "González", "Gaitan", "Galan", "Gambía", "García",
                "Hernández", "Herrera", "Hidalgo", "Huertas", "Hurtado",
                "Ibarra", "IbanÃ©z", "Iglesias", "Infante", "Izaguirre",
                "Jerez", "Jacón", "Jiménez", "Jácamo", "Juárez",
                "López", "Lamas", "Lagos", "Labrador", "Lara", "Lí", "Leviatán",
                "Madrigal", "Molina", "Mendez", "Manzanares", "Monestel", "Molinares", "Matarrita", "Mata", "Monge", "Mora", "Murillo", "Mena", "Marón", "Mendoza", "Matamoros",
                "Nuez", "Noguera", "Naranjo", "Navas", "Nicolas",
                "Ocampo", "Obregón", "Ochoa", "Ojeda", "Cordones",
                "Pacheco", "Palacios", "Palma", "Padilla", "Paniagua", "Pomares", "Picado", "Perez", "Peraza", "Pizarro", "Parra",
                "QuirÃ³s", "Quintero", "Quintana", "Quiroga", "Quintanilla", "Quesada",
                "Ruiz", "Ramírez", "Roldan", "Redondo", "Rivera", "Rodriguez", "Reyes", "Rueda",
                "Saborío", "Sanchez", "Salas", "Sanz", "Sancho", "Sanabría", "Soto", "Sequeira", "Sibaja", "Solano",
                "Talavera", "Tenorio", "Trujillo", "Tijerino", "Torres",
                "Ulloa", "Ugalde", "UreÃ±a", "Urbina", "Ugarte",
                "Vega", "Vargas", "Valencia", "Vallejo", "Varela", "Vizcano", "Valdez", "Vindas", "Villalobos", "Villanueva", "Villegas", "Villagra",
                "Williams", "Wright", "Wong", "Walker", "Watson", "Wells", "White", "Ward", "Wheeler", "Warren", "Wade", "Walters", "Waltz",
                "Zamora", "Zarate", "Zumbado"
        };
        return apellidos[rnd.nextInt(apellidos.length)];
    }

    // Creates a cedula or identification number
    public int Cedula() {
        String ced;
        Random rnd = new Random();

        ced = String.valueOf(rnd.nextInt(7) + 1);
        ced = ced.concat(ponCeros(String.valueOf(rnd.nextInt(1000)), 4) + ponCeros(String.valueOf(rnd.nextInt(1000)), 4));

        return Integer.parseInt(ced);
    }


//    public int Precio(f) {
//        int PrecioFinal;
//
//
//
//
//
//        return int(ced);
//    }


    // Method to get the Costa Rican province based on the counter value
    public String Provincia(int i) {

        String Provincia = "";

        if (i == 1) {
            Provincia = "San José";
        }
        if (i == 2) {
            Provincia = "Alajuela";
        }
        if (i == 3) {
            Provincia = "Cartago";
        }
        if (i == 4) {
            Provincia = "Heredia";
        }
        if (i == 5) {
            Provincia = "Guanacaste";
        }
        if (i == 6) {
            Provincia = "Puntarenas";
        }
        if (i == 7) {
            Provincia = "Limón";
        }

        return Provincia;
    }

    ;


    public String ProvinciaRandom() {

        Random rnd = new Random();
        int i = rnd.nextInt(7);

        String Provincia = "";

        if (i == 1) {
            Provincia = "San José";
        }
        if (i == 2) {
            Provincia = "Alajuela";
        }
        if (i == 3) {
            Provincia = "Cartago";
        }
        if (i == 4) {
            Provincia = "Heredia";
        }
        if (i == 5) {
            Provincia = "Guanacaste";
        }
        if (i == 6) {
            Provincia = "Puntarenas";
        }
        if (i == 7) {
            Provincia = "Limón";
        }

        return Provincia;
    }

    ;


    public String Rol() {
        Random rnd = new Random();
        String Rol[] = {
                "Capitán", "Copiloto", "Asistente", "Asistente"
        };
        return Rol[rnd.nextInt(Rol.length)];
    }


    public String Email() {
        Random rnd = new Random();
        String Relacion[] = {
                "@gmail.com", "@yahoo.com", "@outlook.com", "@hotmail.com", "@mail.com"
        };
        return Relacion[rnd.nextInt(Relacion.length)];
    }

    public static LocalDate randomDate() {


        Random random = new Random();

        // Define the start and end dates for the range
        LocalDate startDate = LocalDate.of(2024, Month.APRIL, 1);
        LocalDate endDate = LocalDate.of(2024, Month.JUNE, 30);

        // Calculate the number of days between the start and end dates
        long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(startDate, endDate);

        // Generate a random number of days to add to the start date
        long randomDays = random.nextInt((int) daysBetween + 1);

        // Generate the random date
        return startDate.plusDays(randomDays);
    }


    public double Peso() {
        Random rnd = new Random();
        // Generate a 10-digit phone number
        double phoneNumber = rnd.nextDouble(15.0);
        return (phoneNumber);
    }


    public int CedulaObtain() {

        functions f = new functions();
        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;
        int Cedula = 0;

        try {


            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 CedulaClientes FROM Personel  WHERE Rol = 'Capitán' AND VueloAsignado IS NULL");
            ir = insert.executeQuery();
            if (ir.next()) {
                Cedula = ir.getInt("CedulaCliente");
                int bs = insert.executeUpdate();
            } else {

                Cedula = 0;
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            Cedula = 0;
        };
        return(Cedula);
    }




    public double Precio(int Peso, int NumVuelo) {
        Random rnd = new Random();


        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;



                int distanciaPartida = 0;
                int distanciaDestino = 0;
                int distanciaFinal = 0;
                try {
                    insert = insertar.toConnect().prepareStatement("SELECT TOP 1 Partida,Destino FROM Vuelo  WHERE NumeroVuelo = '"+ NumVuelo +"'");
                    ir = insert.executeQuery();
                    if (ir.next()) {
                        distanciaPartida = ir.getInt("Partida");
                        distanciaDestino = ir.getInt("Destino");
                    } else {

                        distanciaPartida = 0;
                        distanciaDestino = 0;

                    }

                }catch(SQLException Pain){}


                distanciaFinal = distanciaDestino - distanciaPartida;




        double Kilometraje = distanciaFinal * 100;
        // Generate a 10-digit phone number
        double precioX100km = ((Peso * 0.35) + (346)) / 100;

        double costoAdicional = Kilometraje;

        double precio = precioX100km + costoAdicional;






        return (precio);
    }







    public int Telefono() {
        Random rnd = new Random();
        // Generate a 10-digit phone number
        int phoneNumber = rnd.nextInt(99999999);
        String NumberText = "Dos";
        String.valueOf(phoneNumber);
        return (phoneNumber);
    }



    // Select a random biological sex
    public char Sexo(){
        Random rnd = new Random();
        char Sx[] = {'F','M'};
        return Sx[rnd.nextInt(2)];
    }

    // Creates a civil status
    public char estCivil(){
        Random rnd = new Random();
        char Es[] = {'S','C','D','V','U'};
        return Es[rnd.nextInt(5)];
    }

    // Creates a birthdate
    public String fecNac(String año,int rango,int meses){
        Random rnd = new Random();
        String expre;

        //Calculate day between 1 and 31
        expre = ponCeros(String.valueOf(rnd.nextInt(31)+1),2)+"/";

        //Calculate month between 1 and 12
        expre = expre.concat(ponCeros(String.valueOf(rnd.nextInt(meses)+1),2)+"/");

        //Calculate year since 1960 at today
        expre = expre.concat(String.valueOf(rnd.nextInt(rango)+año));

        return expre;
    }//End fecNac function

    public String fecVuelo(String año,int meses){
        Random rnd = new Random();
        String expre;

        //Calculate day between 1 and 31
        expre = ponCeros(String.valueOf(rnd.nextInt(31)+1),2)+"-";

        //Calculate month between 1 and 12
        expre = expre.concat(ponCeros(String.valueOf(rnd.nextInt(meses)+1),2)+"-");

        //Calculate year since 1960 at today
        expre = expre.concat(String.valueOf(año));

        return expre;
    }//End fecNac function

}
