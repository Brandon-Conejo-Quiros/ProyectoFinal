package AllThatStuff__.views;

import AllThatStuff__.Controllers.ctrl_Persona;
import AllThatStuff__.Models.mdl_Persona;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class frm_Datos_Clientes extends JInternalFrame{
    // Declare the visual components



    private JPanel pnl_Principal;
    private JPanel pnl_Datos;
    private JPanel pnl_Botones;
    private JPanel pnl_Buscar;
    private JLabel lbl_Cedula;
    private JLabel lbl_Nombre;
    private JLabel lbl_Apellido1;
    private JLabel lbl_Apellido2;
    private JLabel lbl_Telefono;
    private JLabel lbl_Correo;
    private JLabel lbl_FechaNac;
    private JTextField txt_Cedula;
    private JTextField txt_Nombre;
    private JTextField txt_Apellido_1;
    private JTextField txt_Apellido_2;
    private JTextField txt_Telefono;
    private JTextField txt_Correo;
    private JTextField txt_FechaNac;
    private JButton btn_Insertar;
    private JButton btn_Modificar;
    private JButton btn_Eliminar;
    private JButton btn_Salir;
    private JButton btn_Buscar;

    private int idPersona = 0;

    // Constructor
    public frm_Datos_Clientes() {
        // Set basic internal frame configuration properties
        super("Datos Personales");
        this.createUIComponents();
        this.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        this.setContentPane(pnl_Principal);

        // Set the size, location, and other properties of the internal frame
        this.setSize(800, 400);
        this.setResizable(false);
        this.setLocation(10, 10);

        // Set the internal frame behavior
        this.setClosable(true);
        this.setIconifiable(true);
        this.setMaximizable(false);






        // Add the event listeners of the all buttons
        this.btn_Insertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Insertar");
                insertar();
            }
        });

        this.btn_Modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Modificar");
                modificar();
            }
        });

        this.btn_Eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Eliminar");
                eliminar();
            }
        });

        this.btn_Salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(JOptionPane.showConfirmDialog(null, "¿Desea cerrar la ventana...?", "Salir", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                    dispose();
                }
            }
        });

        // Set the event listener of the txt_Cedula field
        this.txt_Cedula.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    buscar();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Set the event listener of the btn_Buscar button
        this.btn_Buscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscar2();
            }
        });

        // Initialize the interface
        this.iniInterface();

        // Create an instance of the ctrl_Persona class
        ctrl_Persona ctrlPer = new ctrl_Persona();

        // Validate the current connection is active
        try {
            if(!ctrlPer.get_Conectado()){
                this.desActivar();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }





    // Create the components
    private void createUIComponents() {
        // Create the panels
        pnl_Principal = new JPanel();
        pnl_Principal.setLayout(new BorderLayout());
        pnl_Principal.setPreferredSize(new Dimension(800,400));

        // Create the sub panels
        pnl_Datos = new JPanel();
        pnl_Datos.setLayout(new GridLayout(5, 2));
        pnl_Datos.setPreferredSize(new Dimension(400,125));
        pnl_Datos.setBorder(BorderFactory.createEmptyBorder(10,10,5,10));

        pnl_Botones = new JPanel();
        pnl_Botones.setLayout(new GridLayout(1, 4));
        pnl_Botones.setPreferredSize(new Dimension(400,75));
        pnl_Botones.setBorder(BorderFactory.createEmptyBorder(5,10,5,10));

        pnl_Buscar = new JPanel();
        pnl_Buscar.setLayout(new GridLayout(1, 2));
        pnl_Buscar.setPreferredSize(new Dimension(200,25));

        // Create the labels
        lbl_Cedula = new JLabel("Cédula:");
        lbl_Nombre = new JLabel("Nombre:");
        lbl_Apellido1 = new JLabel("Apellido 1:");
        lbl_Apellido2 = new JLabel("Apellido 2:");
        lbl_Telefono = new JLabel("Telefono:");
        lbl_Correo = new JLabel("Correo:");
        lbl_FechaNac = new JLabel("Fecha de Nacimiento:");


        // Create the text fields
        txt_Cedula = new JTextField();
        txt_Nombre = new JTextField();
        txt_Apellido_1 = new JTextField();
        txt_Apellido_2 = new JTextField();
        txt_Telefono = new JTextField();
        txt_Correo = new JTextField();
        txt_FechaNac = new JTextField();

        // Create the buttons
        btn_Insertar = new JButton("Insertar");
        btn_Modificar = new JButton("Modificar");
        btn_Eliminar = new JButton("Eliminar");
        btn_Salir = new JButton("Salir");

        btn_Buscar = new JButton();
        btn_Buscar.setToolTipText("Buscar por cédula");
        btn_Buscar.setIcon(new ImageIcon(this.getClass().getResource("/AllThatStuff__/resources/images/iconos/list_users.gif")));
        btn_Buscar.setPreferredSize(new Dimension(25,25));

        // Add the components to the panels
        pnl_Buscar.add(txt_Cedula);
        pnl_Buscar.add(btn_Buscar);

        pnl_Datos.add(lbl_Cedula);
        pnl_Datos.add(pnl_Buscar);

        pnl_Datos.add(lbl_Nombre);
        pnl_Datos.add(txt_Nombre);

        pnl_Datos.add(lbl_Apellido1);
        pnl_Datos.add(txt_Apellido_1);

        pnl_Datos.add(lbl_Apellido2);
        pnl_Datos.add(txt_Apellido_2);

//        pnl_Datos.add(lbl_Telefono);
//        pnl_Datos.add(txt_Telefono);
//
//        pnl_Datos.add(lbl_Correo);
//        pnl_Datos.add(txt_Correo);



        pnl_Botones.add(btn_Insertar);
        pnl_Botones.add(btn_Modificar);
        pnl_Botones.add(btn_Eliminar);
        pnl_Botones.add(btn_Salir);

        // Add the panels to the main panel
        pnl_Principal.add(pnl_Datos,BorderLayout.PAGE_START);
        pnl_Principal.add(pnl_Botones, BorderLayout.CENTER);

        // Pack the internal frame
        this.pack();
    }





    // Init the interface
    private void iniInterface(){
        // Set the idPerson to 0
        idPersona = 0;

        // Clear all the fields
        txt_Cedula.setText("");
        txt_Nombre.setText("");
        txt_Apellido_1.setText("");
        txt_Apellido_2.setText("");
        txt_Telefono.setText("");
        txt_Correo.setText("");
        txt_FechaNac.setText("");

        // Disable the buttons
        btn_Insertar.setEnabled(true);
        btn_Modificar.setEnabled(true);
        btn_Eliminar.setEnabled(true);

        // Set the focus on the first field
        txt_Cedula.requestFocus();
    }



    // Deactivate the text fields
    private void desActivar(){
        // Disable the all text fields
        for (Object obj : pnl_Datos.getComponents()) {
            if (obj instanceof JTextField) {
                ((JTextField) obj).setEnabled(false);
            }
        }
        JOptionPane.showMessageDialog(null, "El usuario no se ha autenticado...!", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }



    // Search the person by idCard or Cedula
    private void buscar() throws SQLException {
        String cedula = txt_Cedula.getText();
        if(cedula.isEmpty()){
            // Show the message if cedula is empty
            JOptionPane.showMessageDialog(null, "Debe ingresar la cédula", "Error", JOptionPane.ERROR_MESSAGE);
            txt_Cedula.requestFocus();
        }else{
            if(cedula.length() != 9){
                // Show the message if cedula is not 9 digits
                JOptionPane.showMessageDialog(null, "La cédula debe tener 9 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                txt_Cedula.requestFocus();
            }else{
                // Create an instance of the mdl_Persona class in null
                mdl_Persona persona = null;

                // Seek the idCard or cedula of the person
                try {
                    // Instantiate the ctrl_Persona class
                    ctrl_Persona ctrlPer = new ctrl_Persona();

                    // Get the person by idCard or cedula
                    persona = ctrlPer.get_Persona(Integer.parseInt(cedula));
                } catch (Exception e) {
                    // Show the error message from the exception
                    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
                if(persona != null){
                    // Set the values of the person
                    idPersona = persona.getId();
                    txt_Nombre.setText(persona.getNombre());
                    txt_Apellido_1.setText(persona.getApell1());
                    txt_Apellido_2.setText(persona.getApell2());


                    // Enable the buttons
                    btn_Insertar.setEnabled(true);
                    btn_Modificar.setEnabled(true);
                    btn_Eliminar.setEnabled(true);
                }else{
                    // Clear all the fields
                    txt_Nombre.setText("");
                    txt_Apellido_1.setText("");
                    txt_Apellido_2.setText("");
                    txt_FechaNac.setText("");

                    // Enable the buttons
                    btn_Insertar.setEnabled(true);
                    btn_Modificar.setEnabled(true);
                    btn_Eliminar.setEnabled(true);
                }

                // Set the focus on the first field
                txt_Nombre.requestFocus();
            }
        }
    }



    // Call the frm_LstDatos form to search the person by idCard or Cedula
    private void buscar2(){
        // Create a JDialog instance of the frm_LstDatos form
        frm_LstDatos frmLst = new frm_LstDatos();
        frmLst.setVisible(true);

        // Verify if the cedula is greater than 0
        if(frm_LstDatos.recCedula > 0) {
            // Set the cedula value in the txt_Cedula field
            txt_Cedula.setText(String.valueOf(frm_LstDatos.recCedula));
            try {
                // Call the buscar method
                buscar();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Set the recCedula to 0
            frm_LstDatos.recCedula = 0;
        }
    }


    // Insert new data person
    private void insertar(){
        // Get the values of the fields in local variables
        String cedula = txt_Cedula.getText();
        String nombre = txt_Nombre.getText();
        String apellido1 = txt_Apellido_1.getText();
        String apellido2 = txt_Apellido_2.getText();
        String telefono = txt_Apellido_1.getText();
        String correo = txt_Apellido_2.getText();
        String fechaNac = txt_FechaNac.getText();



        // Validate the fields are not empty
        if(cedula.isEmpty() || nombre.isEmpty() || apellido1.isEmpty() || apellido2.isEmpty()){
            JOptionPane.showMessageDialog(null, "Debe ingresar todos los datos", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
            // Insert the data
            try {
                mdl_Persona persona = new mdl_Persona(0, cedula, nombre, apellido1, apellido2, telefono,correo);
                ctrl_Persona ctrlPer = new ctrl_Persona();
                ctrlPer.add_Persona(persona);
                JOptionPane.showMessageDialog(null, "Datos insertados correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                iniInterface();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }



    // Modify the person data by idCard or Cedula
    private void modificar(){
        // Get the values of the fields in local variables
        String cedula = txt_Cedula.getText();
        String nombre = txt_Nombre.getText();
        String apellido1 = txt_Apellido_1.getText();
        String apellido2 = txt_Apellido_2.getText();
        String telefono = txt_Telefono.getText();
        String correo = txt_Correo.getText();
//        String fechaNac = txt_FechaNac.getText();

        // Validate the fields are not empty
        if(cedula.isEmpty() || nombre.isEmpty() || apellido1.isEmpty() || apellido2.isEmpty()){
            JOptionPane.showMessageDialog(null, "Debe ingresar todos los datos", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
            // Update the data
            try {
                mdl_Persona persona = new mdl_Persona(idPersona, cedula, nombre, apellido1, apellido2, telefono, correo);
                ctrl_Persona ctrlPer = new ctrl_Persona();
                ctrlPer.upd_Persona(persona);
                JOptionPane.showMessageDialog(null, "Datos modificados correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                iniInterface();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Delete the person data by idCard or Cedula
    private void eliminar() {
        // Validate the fields are not empty
        String cedula = txt_Cedula.getText().trim();
        if (cedula.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar una identificación válida", "Error", JOptionPane.ERROR_MESSAGE);
            txt_Cedula.requestFocus();
        } else {
            // Delete the data
            try {
                ctrl_Persona ctrlPer = new ctrl_Persona();
                ctrlPer.del_Persona(cedula);

                JOptionPane.showMessageDialog(null, "Datos eliminados correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                iniInterface();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}
