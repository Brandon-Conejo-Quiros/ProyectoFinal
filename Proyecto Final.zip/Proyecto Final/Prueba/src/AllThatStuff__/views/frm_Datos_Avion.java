package AllThatStuff__.views;

import AllThatStuff__.Controllers.ctrl_Avion;
import AllThatStuff__.Models.mdl_Aviones;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class frm_Datos_Avion extends JInternalFrame{
    // Declare the visual components
    private JPanel pnl_Principal;
    private JPanel pnl_Datos;
    private JPanel pnl_Botones;
    private JPanel pnl_Buscar;
    private JLabel lbl_NumeroVuelo;
    private JLabel lbl_CapitánCedula;
    private JLabel lbl_CopilotoCedula;
    private JLabel lbl_AsistenteCedula1;
    private JLabel lbl_AsistenteCedula2;
    private JLabel lbl_AeropuertoPartidaID;
    private JLabel lbl_AeropuertoPartidaNombre;
    private JLabel lbl_AeropuertoDestinoID;
    private JLabel lbl_AeropuertoDestinoNombre;
    private JTextField txt_NumeroVuelo;
    private JTextField txt_CapitánCedula;
    private JTextField txt_CopilotoCedula;
    private JTextField txt_AsistenteCedula1;
    private JTextField txt_AsistenteCedula2;
    private JTextField txt_AeropuertoPartidaID;
    private JTextField txt_AeropuertoPartidaNombre;
    private JTextField txt_AeropuertoDestinoID;
    private JTextField txt_AeropuertoDestinoNombre;
    private JButton btn_Insertar;
    private JButton btn_Modificar;
    private JButton btn_Eliminar;
    private JButton btn_Salir;
    private JButton btn_Buscar;

    private int idPersona = 0;

    // Constructor
    public frm_Datos_Avion() {
        // Set basic internal frame configuration properties
        super("Datos de Vuelos");
        this.createUIComponents();
        this.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        this.setContentPane(pnl_Principal);

        // Set the size, location, and other properties of the internal frame
        this.setSize(800, 400);
        this.setResizable(false);
        this.setLocation(300, 100);

        // Set the internal frame behavior
        this.setClosable(true);
        this.setIconifiable(true);
        this.setMaximizable(false);

        // Add the event listeners of the all buttons
        this.btn_Insertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Buscar");
                try{

                    buscar();

                }catch(SQLException error){}
            }
        });

;

        this.btn_Salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(JOptionPane.showConfirmDialog(null, "¿Desea cerrar la ventana...?", "Salir", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                    dispose();
                }
            }
        });

        // Set the event listener of the txt_Cedula field
        this.txt_NumeroVuelo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{

                    buscar();

                }catch(SQLException error){}
            }
        });

        // Set the event listener of the btn_Buscar button
        this.btn_Buscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                    buscar2();

            }
        });

        // Initialize the interface
        this.iniInterface();

        // Create an instance of the ctrl_Persona class
        ctrl_Avion ctrlPer = new ctrl_Avion();

        // Validate the current connection is active
        try {
            if(!ctrlPer.get_Conectado()){
                this.desActivar();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Create the components
    private void createUIComponents() {
        // Create the panels
        pnl_Principal = new JPanel();
        pnl_Principal.setLayout(new BorderLayout());
        pnl_Principal.setPreferredSize(new Dimension(400,200));

        // Create the sub panels
        pnl_Datos = new JPanel();
        pnl_Datos.setLayout(new GridLayout(5, 2));
        pnl_Datos.setPreferredSize(new Dimension(400,125));
        pnl_Datos.setBorder(BorderFactory.createEmptyBorder(10,10,5,10));

        pnl_Botones = new JPanel();
        pnl_Botones.setLayout(new GridLayout(1, 4));
        pnl_Botones.setPreferredSize(new Dimension(400,75));
        pnl_Botones.setBorder(BorderFactory.createEmptyBorder(5,10,5,10));

        pnl_Buscar = new JPanel();
        pnl_Buscar.setLayout(new GridLayout(1, 2));
        pnl_Buscar.setPreferredSize(new Dimension(200,25));

        // Create the labels
        lbl_NumeroVuelo = new JLabel("Numero de Vuelo:");
        lbl_CapitánCedula = new JLabel("Cedula del Capitán:");
        lbl_CopilotoCedula = new JLabel("Cedula del Copiloto:");
        lbl_AsistenteCedula1 = new JLabel("Cedula del Asistente:");
        lbl_AsistenteCedula2 = new JLabel("Cedula del Asistente:");
        lbl_AeropuertoPartidaID = new JLabel("ID De La Partida:");
        lbl_AeropuertoPartidaNombre = new JLabel("Nombre De La Partida:");
        lbl_AeropuertoDestinoID = new JLabel("ID Del Destino:");
        lbl_AeropuertoDestinoNombre = new JLabel("Nombre Del Destino:");
        // Create the text fields
        txt_NumeroVuelo = new JTextField();
        txt_CapitánCedula = new JTextField();
        txt_CopilotoCedula = new JTextField();
        txt_AsistenteCedula1 = new JTextField();
        txt_AsistenteCedula2 = new JTextField();
        txt_AeropuertoPartidaID = new JTextField();
        txt_AeropuertoPartidaNombre = new JTextField();
        txt_AeropuertoDestinoID = new JTextField();
        txt_AeropuertoDestinoNombre = new JTextField();


        // Create the buttons
        btn_Insertar = new JButton("Buscar");
        btn_Modificar = new JButton("Modificar");
        btn_Eliminar = new JButton("Eliminar");
        btn_Salir = new JButton("Salir");

        btn_Buscar = new JButton();
        btn_Buscar.setToolTipText("Buscar por numero de avión");
        btn_Buscar.setIcon(new ImageIcon(this.getClass().getResource("/AllThatStuff__/resources/images/iconos/list_users.gif")));
        btn_Buscar.setPreferredSize(new Dimension(25,25));

        // Add the components to the panels
        pnl_Buscar.add(txt_NumeroVuelo);
        pnl_Buscar.add(btn_Buscar);

        pnl_Datos.add(lbl_NumeroVuelo);
        pnl_Datos.add(pnl_Buscar);

        pnl_Datos.add(lbl_CapitánCedula);
        pnl_Datos.add(txt_CapitánCedula);

        pnl_Datos.add(lbl_CopilotoCedula);
        pnl_Datos.add(txt_CopilotoCedula);

        pnl_Datos.add(lbl_AsistenteCedula1);
        pnl_Datos.add(txt_AsistenteCedula1);

        pnl_Datos.add(lbl_AeropuertoDestinoID);
        pnl_Datos.add(txt_AeropuertoDestinoID);

        pnl_Datos.add(lbl_AeropuertoDestinoNombre);
        pnl_Datos.add(txt_AeropuertoDestinoNombre);

        pnl_Datos.add(lbl_AeropuertoPartidaID);
        pnl_Datos.add(txt_AeropuertoPartidaID);

        pnl_Datos.add(lbl_AeropuertoPartidaNombre);
        pnl_Datos.add(txt_AeropuertoPartidaNombre);



        pnl_Botones.add(btn_Insertar);
//        pnl_Botones.add(btn_Modificar);
//        pnl_Botones.add(btn_Eliminar);
        pnl_Botones.add(btn_Salir);

        // Add the panels to the main panel
        pnl_Principal.add(pnl_Datos,BorderLayout.PAGE_START);
        pnl_Principal.add(pnl_Botones, BorderLayout.CENTER);

        // Pack the internal frame
        this.pack();
    }

    // Init the interface
    private void iniInterface(){
        // Set the idPerson to 0
        idPersona = 0;

        // Clear all the fields
        txt_NumeroVuelo.setText("");
        txt_CapitánCedula.setText("");
        txt_CopilotoCedula.setText("");
        txt_AsistenteCedula1.setText("");
        txt_AsistenteCedula2.setText("");

        // Disable the buttons
        btn_Insertar.setEnabled(true);
        btn_Modificar.setEnabled(true);
        btn_Eliminar.setEnabled(true);

        // Set the focus on the first field
        txt_NumeroVuelo.requestFocus();
    }

    // Deactivate the text fields
    private void desActivar(){
        // Disable the all text fields
        for (Object obj : pnl_Datos.getComponents()) {
            if (obj instanceof JTextField) {
                ((JTextField) obj).setEnabled(false);
            }
        }
        JOptionPane.showMessageDialog(null, "El usuario no se ha autenticado...!", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }

    // Search the person by idCard or Cedula
    private void buscar() throws SQLException {
        String NumeroVuelo = txt_NumeroVuelo.getText();
        if(NumeroVuelo.isEmpty()){
            // Show the message if cedula is empty
            JOptionPane.showMessageDialog(null, "Debe ingresar el numero de vuelo", "Error", JOptionPane.ERROR_MESSAGE);
            txt_NumeroVuelo.requestFocus();
        }else{

                // Create an instance of the mdl_Persona class in null
                mdl_Aviones persona = null;

                // Seek the idCard or cedula of the person
                try {
                    // Instantiate the ctrl_Persona class
                    ctrl_Avion ctrlPer = new ctrl_Avion();

                    // Get the person by idCard or cedula
                    persona = ctrlPer.get_Vuelos(Integer.parseInt(NumeroVuelo));
                } catch (Exception e) {
                    // Show the error message from the exception
                    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
                if(persona != null) {
                    // Set the values of the person
                    idPersona = persona.getId();
                    txt_CapitánCedula.setText(persona.getCedulaCap());
                    txt_CopilotoCedula.setText(persona.getCedulaCop());
                    txt_AsistenteCedula1.setText(persona.getAs1());
                    txt_AeropuertoPartidaID.setText(persona.getPartida());
                    txt_AeropuertoDestinoID.setText(persona.getDestino());

                    int PartidaID = Integer.parseInt(persona.getPartida());
                    int DestinoID = Integer.parseInt(persona.getDestino());
                    txt_AeropuertoPartidaNombre.setText(persona.getPartidaNom(PartidaID));
                    txt_AeropuertoDestinoNombre.setText(persona.getDestinoNom(DestinoID));


                    // Enable the buttons
                    btn_Insertar.setEnabled(true);
                    btn_Modificar.setEnabled(true);
                    btn_Eliminar.setEnabled(true);
                }else{
                    // Clear all the fields
                    txt_CapitánCedula.setText("");
                    txt_CopilotoCedula.setText("");
                    txt_AsistenteCedula1.setText("");
                    txt_AsistenteCedula2.setText("");
                    txt_AeropuertoPartidaID.setText("");
                    txt_AeropuertoDestinoID.setText("");
                    txt_AeropuertoPartidaNombre.setText("");
                    txt_AeropuertoDestinoNombre.setText("");

                    // Enable the buttons
                    btn_Insertar.setEnabled(true);
                    btn_Modificar.setEnabled(true);
                    btn_Eliminar.setEnabled(true);
                }

                // Set the focus on the first field
                txt_CapitánCedula.requestFocus();
            }

    }

    // Call the frm_LstDatos form to search the person by idCard or Cedula
    private void buscar2(){
        // Create a JDialog instance of the frm_LstDatos form
        frm_LstDatos_Avion frmLst = new frm_LstDatos_Avion();
        frmLst.setVisible(true);

        // Verify if the cedula is greater than 0
        if(frm_LstDatos_Avion.recNumeroVuelo >= 0) {
            // Set the cedula value in the txt_Cedula field
            txt_NumeroVuelo.setText(String.valueOf(frm_LstDatos_Avion.recNumeroVuelo));
            try {
                // Call the buscar method
                buscar();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Set the recCedula to 0
            frm_LstDatos_Avion.recNumeroVuelo = 0;
        }
    }


    private void buscar3() {
        // Create a JDialog instance of the frm_LstDatos form



        String NumVuelo = txt_NumeroVuelo.getText();
        if (NumVuelo.isEmpty()) {

            frm_LstDatos_Avion_Asientos frmLst = new frm_LstDatos_Avion_Asientos(NumVuelo);
            frmLst.setVisible(true);
            // Show the message if cedula is empty
            JOptionPane.showMessageDialog(null, "Debe ingresar el numero de vuelo", "Error", JOptionPane.ERROR_MESSAGE);
            txt_NumeroVuelo.requestFocus();
        } else {

            // Verify if the cedula is greater than 0
            if (frm_LstDatos_Avion.recNumeroVuelo >= 0) {
                // Set the cedula value in the txt_Cedula field
                txt_NumeroVuelo.setText(String.valueOf(frm_LstDatos_Avion.recNumeroVuelo));
                try {
                    // Call the buscar method
                    buscar();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }

                // Set the recCedula to 0
                frm_LstDatos_Avion.recNumeroVuelo = 0;
            }
        }
    }
    // Insert new data person


}
