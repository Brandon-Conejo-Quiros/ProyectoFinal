package AllThatStuff__.views;

import javax.swing.*;
import java.util.Arrays;

public class frm_Principal extends JFrame {
    private JDesktopPane desktop;

    public frm_Principal() {
        initComponents();
    }
    private void initComponents() {
        // Window basic configuration
        this.setTitle("Aerotaxi");
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        // Create a desktop panel
        desktop = new JDesktopPane();

        // Create a menu bar
        JMenuBar menuBar = iniMenuBar();

        // Create a tool bar
        JToolBar toolBar = iniToolBar();

        // Add the menu bar to the window
        this.setJMenuBar(menuBar);

        // Layout configuration, adding the toolbar and desktop
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(toolBar, GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
                .addComponent(desktop)
            );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addComponent(toolBar, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(desktop))
        );

        //pack();
    }

    private JMenuBar iniMenuBar(){
        // Menu configuration
        JMenuBar menuBar = new JMenuBar();

        // Create a menu Mantenimiento
        JMenu mnu_Manteni = new JMenu("Mantenimientos");

        // Create menu items for the menu Mantenimiento
        JMenuItem mni_Aviones = new JMenuItem("Aviones");
        JMenuItem mni_Clientes = new JMenuItem("Clientes");
        JMenuItem mni_Comprar = new JMenuItem("Comprar");

        // Add the menu items to the menu Mantenimiento
        mnu_Manteni.add(mni_Aviones);
        mnu_Manteni.add(mni_Clientes);
        mnu_Manteni.add(mni_Comprar);

        // Bind the events to the menu items
        mni_Clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clientes();
            }
        });


        // Create a menu Salir
        JMenu mnu_Sesion = new JMenu("Sesión");

        // Create a menu item for the menu Salir (Log in)
        JMenuItem mni_Iniciar = new JMenuItem("Iniciar sesión");

        // Add the menu item to the menu Sesión
        mnu_Sesion.add(mni_Iniciar);

        // Bind the events to the menu items
        mni_Iniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Autenticar();
            }
        });

        // Create a menu item for the menu Salir (Close application)
        JMenuItem mni_Salir = new JMenuItem("Cerrar la aplicación");

        // Add the menu item to the menu Sesión
        mnu_Sesion.add(mni_Salir);

        // Bind the events to the menu items
        mni_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir();
            }
        });

        // Add the menus to the menu bar
        menuBar.add(mnu_Manteni);
        menuBar.add(mnu_Sesion);

        return menuBar;
    }

    private JToolBar iniToolBar() {
        // Create toolbar object
        JToolBar toolBar = new JToolBar();

        // Create buttons for the toolbar
        JButton btn_Aviones = new JButton("Aviones");
        JButton btn_Clientes = new JButton("Clientes");
        JButton btn_Comprar = new JButton("Comprar");
        JButton btn_Salir = new JButton("Salir");

        // set the same dimensions for all buttons
        btn_Aviones.setMaximumSize(new java.awt.Dimension(80, 25));
        btn_Clientes.setMaximumSize(new java.awt.Dimension(80, 25));
        btn_Comprar.setMaximumSize(new java.awt.Dimension(80, 25));
        btn_Salir.setMaximumSize(new java.awt.Dimension(80, 25));

        // Set icons for the buttons
        btn_Aviones.setIcon(new ImageIcon(this.getClass().getResource("/AllThatStuff__/resources/images/iconos/action_go.gif")));
        btn_Clientes.setIcon(new ImageIcon(this.getClass().getResource("/AllThatStuff__/resources/images/iconos/icon_user.gif")));
        btn_Comprar.setIcon(new ImageIcon(this.getClass().getResource("/AllThatStuff__/resources/images/iconos/icon_favourites.gif")));
        btn_Salir.setIcon(new ImageIcon(this.getClass().getResource("/AllThatStuff__/resources/images/iconos/action_stop.gif")));


        // Set tooltips for the buttons
        btn_Aviones.setToolTipText("Mantenimiento de Aviones");
        btn_Clientes.setToolTipText("Mantenimiento de Clientes");
        btn_Comprar.setToolTipText("Comprar boletos");
        btn_Salir.setToolTipText("Salir del sistema");

        // Bind the events to the buttons
        btn_Clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clientes();
            }
        });

        btn_Aviones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Avion();
            }
        });

        btn_Comprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Comprar();
            }
        });

        btn_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir();
            }
        });

        // Add buttons to the toolbar
        toolBar.add(btn_Aviones);
        toolBar.add(btn_Clientes);
        toolBar.add(btn_Comprar);
        toolBar.add(btn_Salir);

        // Return the toolbar
        return toolBar;
    }


    // =================================================================================
    // Declare the events for the menu items and buttons
    // =================================================================================

    // Close application
    private void Salir(){
        if(JOptionPane.showConfirmDialog(this, "¿Desea salir del sistema?", "Salir del sistema", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
            System.exit(0);
        }
    }

    // Validate if the form is already open
    private boolean valiExist(String ventana){
        JInternalFrame[] ventanas = desktop.getAllFrames();
        return !Arrays.asList(ventanas).toString().contains(ventana);
    }

    // Call the form frm_Datos
    private void Clientes(){
        if(valiExist("frm_Datos")){
            frm_Datos_Clientes formita = new frm_Datos_Clientes();
            desktop.add(formita);
            formita.setVisible(true);
        }
    }

    private void Comprar(){
        if(valiExist("frm_Datos")){
            frm_Datos_Comprar formita = new frm_Datos_Comprar();
            desktop.add(formita);
            formita.setVisible(true);
        }
    }

    private void Avion(){
        if(valiExist("frm_Datos_Avion")){
            frm_Datos_Avion formita = new frm_Datos_Avion();
            desktop.add(formita);
            formita.setVisible(true);
        }
    }


    // Call the form frm_Autenticar
    private void Autenticar(){
        if(valiExist("frm_Autenticar")){
            frm_Autenticar formita = new frm_Autenticar();
            desktop.add(formita);
            formita.setVisible(true);
        }
    }
}
