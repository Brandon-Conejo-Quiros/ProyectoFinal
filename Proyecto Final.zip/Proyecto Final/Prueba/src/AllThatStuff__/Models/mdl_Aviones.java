/*================================================================================================
Study Center....: Universidad Técnica Nacional
Campus..........: Pacífico (JRMP)
College career..: Ingeniería en Tecnologías de Información
Period..........: 2C-2024
Course..........: ITI-221 - Programación I
Document........: complete - models - mdl_Persona.java
Goals...........: Reuse the class to create the model of the table Persona
Professor.......: Jorge Ruiz (york)
Student.........:
================================================================================================*/

package AllThatStuff__.Models;

import AllThatStuff__.Conexiones.cls_conex;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

// Import the necessary libraries

public class mdl_Aviones {



    // Create the class attributes
    private int id;
    private String NumeroVuelo;
    private String CedulaCap;
    private String CedulaCop;
    private String As1;
    private String As2;
    private String Partida;
    private String Destino;
    private String PartidaNom;
    private String DestinoNom;

    private String ClienteNombre;
    private String ClienteCedula;
    private String NumeroAsiento;

    // Create the class constructor
        public mdl_Aviones(int id, String NumeroVuelo, String CedulaCapitan, String CedulaCopiloto, String CedulaAsistente1, String CedulaAsistente2, String Partida, String Destino, String NombreP, String NombreD) {
            this.id = id;
            this.NumeroVuelo = NumeroVuelo;
            this.CedulaCap = CedulaCapitan;
            this.CedulaCop = CedulaCopiloto;
            this.As1 = CedulaAsistente1;
            this.As2 = CedulaAsistente2;
            this.Partida = Partida;
            this.Destino = Destino;
            this.PartidaNom = NombreD;
            this.DestinoNom = NombreP;

    }

    // Create the class methods
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getNumeroVuelo() {
        return NumeroVuelo;
    }

    public void setNumeroVuelo(String numeroVuelo) {
        NumeroVuelo = numeroVuelo;
    }

    public String getCedulaCap() {
        return CedulaCap;
    }

    public void setCedulaCap(String cedulaCap) {
        CedulaCap = cedulaCap;
    }

    public String getCedulaCop() {
        return CedulaCop;
    }

    public void setCedulaCop(String cedulaCop) {
        CedulaCop = cedulaCop;
    }

    public void setPartida(String partida) {
        Partida = partida;
    }

    public void setDestino(String destino) {
        Destino = destino;
    }

    public String getAs1() {
        return As1;
    }

    public void setAs1(String as1) {
        As1 = as1;
    }

    public String getAs2() {
        return As2;
    }

    public void setAs2(String as2) {
        As2 = as2;
    }



    public String getPartida() {
        return Partida;
    }

    public String getDestino() {
        return Destino;
    }

    public String getPartidaNom(int Partida) {
        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;

            try {

                insert = insertar.toConnect().prepareStatement("SELECT TOP 1 Nombre FROM Aeropuertos WHERE NumAeropuerto = '"+ Partida +"'");
                ir = insert.executeQuery(); // Execute the query

                // Process the result
                if (ir.next()) {
                    PartidaNom = ir.getString("Nombre");

                }
            }catch(SQLException err){}
        return PartidaNom;
    }

    public void setPartidaNom(String partidaNom) {
        PartidaNom = partidaNom;
    }

    public String getDestinoNom(int Destino) {

        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;

        try {

            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 Nombre FROM Aeropuertos WHERE NumAeropuerto = '"+ Destino +"'");
            ir = insert.executeQuery(); // Execute the query

            // Process the result
            if (ir.next()) {
                DestinoNom = ir.getString("Nombre");

            }
        }catch(SQLException err){}

        return DestinoNom;
    }

    public void setDestinoNom(String destinoNom) {
        DestinoNom = destinoNom;
    }


    public String getClienteNombre(String CedulaCliente) {

        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;

        try {

            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 ClienteNombre FROM Clientes WHERE CedulaCliente = '"+ CedulaCliente +"'");
            ir = insert.executeQuery(); // Execute the query

            // Process the result
            if (ir.next()) {
                DestinoNom = ir.getString("Nombre");

            }
        }catch(SQLException err){}

        return ClienteNombre;
    }

    public void setClienteNombre(String clienteNombre) {
        ClienteNombre = clienteNombre;
    }

    public String getClienteCedula() {

        cls_conex insertar = new cls_conex();
        PreparedStatement insert = null;
        ResultSet ir = null;

        try {

            insert = insertar.toConnect().prepareStatement("SELECT TOP 1 Nombre FROM Aeropuertos WHERE NumAeropuerto = '"+ Destino +"'");
            ir = insert.executeQuery(); // Execute the query

            // Process the result
            if (ir.next()) {
                DestinoNom = ir.getString("Nombre");

            }
        }catch(SQLException err){}

        return ClienteCedula;
    }

    public void setClienteCedula(String clienteCedula) {
        ClienteCedula = clienteCedula;
    }

    public String getNumeroAsiento() {
        return NumeroAsiento;
    }

    public void setNumeroAsiento(String numeroAsiento) {
        NumeroAsiento = numeroAsiento;
    }
}















//class mdl_Aviones_Asientos {
//    // Create the class attributes
//    private int id;
//    private String NumeroVuelo;
//    private String CedulaPersona;
//    private String NombrePersona;
//
//    // Create the class constructor
//    public mdl_Aviones_Asientos(int id, String NumeroVuelo, String CedulaCapitan, String CedulaCopiloto, String CedulaAsistente1, String CedulaAsistente2, String Partida, String Destino, String CedulaP, String NombreP) {
//        this.id = id;
//        this.CedulaPersona = CedulaP;
//        this.NombrePersona = NombreP;
//
//    }
//
//    // Create the class methods
//    public int getId() {
//        return id;
//    }
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String getNumeroVuelo() {
//        return NumeroVuelo;
//    }
//
//    public void setNumeroVuelo(String numeroVuelo) {
//        NumeroVuelo = numeroVuelo;
//    }
//
//
//}
