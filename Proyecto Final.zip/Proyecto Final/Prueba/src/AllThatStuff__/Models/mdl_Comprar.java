/*================================================================================================
Study Center....: Universidad Técnica Nacional
Campus..........: Pacífico (JRMP)
College career..: Ingeniería en Tecnologías de Información
Period..........: 2C-2024
Course..........: ITI-221 - Programación I
Document........: complete - models - mdl_Persona.java
Goals...........: Reuse the class to create the model of the table Persona
Professor.......: Jorge Ruiz (york)
Student.........:
================================================================================================*/

package AllThatStuff__.Models;

// Import the necessary libraries
import java.sql.Date;

public class mdl_Comprar {
    // Create the class attributes
    private int id;
    private String cedula;
    private String nombre;
    private String apell1;
    private String apell2;
    private String telefono;
    private String correo;
    private Date fecNac;

    // Create the class constructor
        public mdl_Comprar(int id, String cedula, String nombre, String apell1, String apell2) {
        this.id = id;
        this.cedula = cedula;
        this.nombre = nombre;
        this.apell1 = apell1;
        this.apell2 = apell2;
        this.telefono = telefono;
        this.correo = correo;
    }

    // Create the class methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApell1() {
        return apell1;
    }

    public void setApell1(String apell1) {
        this.apell1 = apell1;
    }

    public String getApell2() {
        return apell2;
    }

    public void setApell2(String apell2) {
        this.apell2 = apell2;
    }


    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public Date getFecNac() {
        return fecNac;
    }

    public void setFecNac(Date fecNac) {
        this.fecNac = fecNac;
    }
}
