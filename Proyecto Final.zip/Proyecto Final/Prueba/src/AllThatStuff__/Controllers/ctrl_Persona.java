/*================================================================================================
Study Center....: Universidad Técnica Nacional
Campus..........: Pacífico (JRMP)
College career..: Ingeniería en Tecnologías de Información
Period..........: 2C-2024
Course..........: ITI-221 - Programación I
Document........: complete - controllers - ctrl_Persona.java
Goals...........: Create the functions to manipulate the data of table Persona, using the
                  connection to a SQL Server or MySQL Server database
Professor.......: Jorge Ruiz (york)
Student.........:
================================================================================================*/

package AllThatStuff__.Controllers;

// import the necessary libraries

import AllThatStuff__.Conexiones.conex_MSSQL;
import AllThatStuff__.Conexiones.config_DB;
import AllThatStuff__.Models.mdl_Persona;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ctrl_Persona {
    // Create the connection variables
    private PreparedStatement stmt = null;
    private ResultSet rs = null;

    // Validate the connection to the database is active
    public boolean get_Conectado(){
        boolean conectado = true;
        try{
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toConnect();
                conex_MSSQL.toDisConnect();
            }
        } catch (SQLException e) {
            conectado = false;
        }
        return conectado;
    }

    // Retrieve all the records from the table Persona
    public ArrayList<mdl_Persona> get_Personas() throws SQLException {
        ArrayList<mdl_Persona> personas;

        // Try to connect to the database engine and prepare the statement
        try {
            // Try to connect to the database and prepare the statement
            if(config_DB.MOTOR.equals("MSSQL")){
                stmt = conex_MSSQL.toConnect().prepareStatement("select * from Clientes");
            }

            // Execute the statement
            rs = stmt.executeQuery();

            // Create an array list to store the records
            personas = new ArrayList<mdl_Persona>();

            // Iterate the result set
            while (rs.next()) {
                // Create an instance of the mdl_Persona class
                mdl_Persona persona = new mdl_Persona(rs.getInt(1), rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));

                // Add the instance to the array list
                personas.add(persona);
            }

            // Try to close
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }

        } catch (SQLException e) {
            // Throw an exception
            throw new SQLException("Error: " + e.getMessage());
        } finally {
            // Try to disconnect from the database
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toDisConnect();
            }
        }

        // Return the array list
        return personas;
    }

    // Retrieve a record from the table Persona by the cedula or id
    public mdl_Persona get_Persona(int ced) throws SQLException {
        mdl_Persona persona = null;

        try {
            // Try to connect to the database and prepare the statement
            if(config_DB.MOTOR.equals("MSSQL")){
                stmt = conex_MSSQL.toConnect().prepareStatement("select * from Clientes where CedulaCliente = ?");
            }

            // Update the statement with the data
            stmt.setInt(1, ced);

            // Execute the statement
            rs = stmt.executeQuery();

            // Iterate the result set
            while (rs.next()) {
                // Create an instance of the mdl_Persona class
                persona = new mdl_Persona(rs.getInt(1), rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
            }

            // Try to close
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }

        } catch (SQLException e) {
            // Throw an exception
            throw new SQLException("Error: " + e.getMessage());
        } finally {
            // Try to disconnect from the database
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toDisConnect();
            }
        }

        // Return the instance of the mdl_Persona class
        return persona;
    }

    // Insert a record into the table Persona
    public void add_Persona(mdl_Persona persona) throws SQLException{
        String auxSql = "";
        try {
            // Try to connect to the database and prepare the statement
            if(config_DB.MOTOR.equals("MSSQL")){
                stmt = conex_MSSQL.toConnect().prepareStatement("exec MeterCliente ?, ?, ?, ?");
            }

            // Update the statement with the data and execute it
            if(persona != null){
                stmt.setString(1, persona.getCedula());
                stmt.setString(2, persona.getNombre());
                stmt.setString(3, persona.getApell1());
                stmt.setString(4, persona.getApell2());

                stmt.execute();
            }

            // Try to close
            if(stmt != null){
                stmt.close();
                stmt = null;
            }

        }catch (SQLException e){
            // Throw an exception
            throw new SQLException("Error: " + e.getMessage());
        }finally{
            // Try to disconnect from the database
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toDisConnect();
            }
        }
    }

    // Update a record in the table Persona by the id
    public void upd_Persona(mdl_Persona persona) throws SQLException{
        String auxSql = "";
        try {
            // Try to connect to the database and prepare the statement
            if(config_DB.MOTOR.equals("MSSQL")){
                stmt = conex_MSSQL.toConnect().prepareStatement("exec CambiarCliente ?, ?, ?, ?");
            }
            // Update the statement with the data and execute it
            if(persona != null){
                stmt.setString(1, persona.getCedula());
                stmt.setString(2, persona.getNombre());
                stmt.setString(3, persona.getApell1());
                stmt.setString(4, persona.getApell2());

                stmt.execute();
            }

            // Try to close
            if(stmt != null){
                stmt.close();
                stmt = null;
            }

        }catch (SQLException e){
            //
            throw new SQLException("Error: " + e.getMessage());
        }finally{
            // Try to disconnect from the database
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toDisConnect();
            }
        }
    }

    // Delete a record from the table Persona by the id
    public void del_Persona(String cedula) throws SQLException {
        PreparedStatement stmt = null; // Declare stmt here
        try {
            // Connect to the database and prepare the statement for MSSQL
            if (config_DB.MOTOR.equals("MSSQL")) {
                stmt = conex_MSSQL.toConnect().prepareStatement("EXEC EliminarCliente ?");
            } else {
                throw new SQLException("Unsupported database engine: " + config_DB.MOTOR);
            }

            // Update the statement with the data and execute it
            if (cedula != null && !cedula.isEmpty()) {
                stmt.setString(1, cedula);
                stmt.execute();
            }
        } catch (SQLException e) {
            // Throw an exception with a detailed error message
            throw new SQLException("Error: " + e.getMessage(), e);
        } finally {
            // Try to close resources and disconnect from the database
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    // Log or handle the error for closing the statement
                    e.printStackTrace();
                }
            }

            if (config_DB.MOTOR.equals("MSSQL")) {
                conex_MSSQL.toDisConnect();
            }
        }
    }


}
