/*================================================================================================
Study Center....: Universidad Técnica Nacional
Campus..........: Pacífico (JRMP)
College career..: Ingeniería en Tecnologías de Información
Period..........: 2C-2024
Course..........: ITI-221 - Programación I
Document........: complete - controllers - ctrl_Persona.java
Goals...........: Create the functions to manipulate the data of table Persona, using the
                  connection to a SQL Server or MySQL Server database
Professor.......: Jorge Ruiz (york)
Student.........:
================================================================================================*/

package AllThatStuff__.Controllers;

// import the necessary libraries

import AllThatStuff__.Conexiones.conex_MSSQL;
import AllThatStuff__.Conexiones.config_DB;
import AllThatStuff__.Models.mdl_Aviones;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ctrl_Avion {
    // Create the connection variables
    private PreparedStatement stmt = null;
    private ResultSet rs = null;

    // Validate the connection to the database is active
    public boolean get_Conectado(){
        boolean conectado = true;
        try{
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toConnect();
                conex_MSSQL.toDisConnect();
            }
        } catch (SQLException e) {
            conectado = false;
        }
        return conectado;
    }

    // Retrieve all the records from the table Persona
    public ArrayList<mdl_Aviones> get_Vuelos() throws SQLException {
        ArrayList<mdl_Aviones> vuelos;

        // Try to connect to the database engine and prepare the statement
        try {
            // Try to connect to the database and prepare the statement
            if(config_DB.MOTOR.equals("MSSQL")){
                stmt = conex_MSSQL.toConnect().prepareStatement("select * from Vuelo");
            }

            // Execute the statement
            rs = stmt.executeQuery();

            // Create an array list to store the records
            vuelos = new ArrayList<mdl_Aviones>();

            // Iterate the result set
            while (rs.next()) {
                // Create an instance of the mdl_Persona class
                mdl_Aviones vuelo = new mdl_Aviones(rs.getInt(1),rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9));

                // Add the instance to the array list
                vuelos.add(vuelo);
            }

            // Try to close
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }

        } catch (SQLException e) {
            // Throw an exception
            throw new SQLException("Error: " + e.getMessage());
        } finally {
            // Try to disconnect from the database
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toDisConnect();
            }
        }

        // Return the array list
        return vuelos;
    }

    // Retrieve a record from the table Persona by the cedula or id
    public mdl_Aviones get_Vuelos(int ced) throws SQLException {
        mdl_Aviones vuelo = null;

        try {
            // Try to connect to the database and prepare the statement
            if(config_DB.MOTOR.equals("MSSQL")){
                stmt = conex_MSSQL.toConnect().prepareStatement("select * from Vuelo where NumeroVuelo = ?");
            }

            // Update the statement with the data
            stmt.setInt(1, ced);

            // Execute the statement
            rs = stmt.executeQuery();

            // Iterate the result set
            while (rs.next()) {
                // Create an instance of the mdl_Persona class
                vuelo = new mdl_Aviones(rs.getInt(1),rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9));
            }

            // Try to close
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }

        } catch (SQLException e) {
            // Throw an exception
            throw new SQLException("Error: " + e.getMessage());
        } finally {
            // Try to disconnect from the database
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toDisConnect();
            }
        }

        // Return the instance of the mdl_Persona class
        return vuelo;
    }



    public mdl_Aviones get_Personas(int numeroVuelo) throws SQLException {
        mdl_Aviones vuelo = null;

        try {
            // Try to connect to the database and prepare the statement
            if(config_DB.MOTOR.equals("MSSQL")){
                stmt = conex_MSSQL.toConnect().prepareStatement("select * from Vuelo where NumeroVuelo = ?");
            }

            // Update the statement with the data
            stmt.setInt(1, numeroVuelo);

            // Execute the statement
            rs = stmt.executeQuery();

            // Iterate the result set
            while (rs.next()) {
                // Create an instance of the mdl_Persona class
                vuelo = new mdl_Aviones(rs.getInt(1),rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9));
            }

            // Try to close
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }

        } catch (SQLException e) {
            // Throw an exception
            throw new SQLException("Error: " + e.getMessage());
        } finally {
            // Try to disconnect from the database
            if(config_DB.MOTOR.equals("MSSQL")){
                conex_MSSQL.toDisConnect();
            }
        }

        // Return the instance of the mdl_Persona class
        return vuelo;
    }

    // Insert a record into the table Persona


}
