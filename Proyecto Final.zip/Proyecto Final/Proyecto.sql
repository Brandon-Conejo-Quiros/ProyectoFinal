CREATE DATABASE Aeropuerto;

GO

use Aeropuerto;


GO


CREATE TABLE Personel(
CedulaPersonel INT PRIMARY KEY,
NombrePersonel VARCHAR(20),
ApellidoPersonel1 VARCHAR(20),
ApellidoPersonel2 VARCHAR(20),
Telefono VARCHAR(20),
Correo VARCHAR (150),
Rol VARCHAR(20),
Sexo CHAR,
VueloAsignado INT
);

GO


CREATE TABLE Aeropuertos(
NumAeropuerto TINYINT PRIMARY KEY IDENTITY(1,1),
Provincia VARCHAR(30)
);
ALTER TABLE Aeropuertos ADD Nombre VARCHAR(100)
 
INSERT INTO Aeropuertos (Provincia, Nombre) VALUES
('San Jos�', 'Aeropuerto Internacional Juan Santamar�a'),
('San Jos�', 'Aeropuerto Tob�as Bola�os'),
('San Jos�', 'Aeropuerto de San Jos�'),
('Alajuela', 'Aeropuerto de Alajuela'),
('Alajuela', 'Aeropuerto La Fortuna'),
('Alajuela', 'Aeropuerto de Ciudad Quesada'),
('Heredia', 'Aeropuerto de Heredia'),
('Heredia', 'Aeropuerto de Santo Domingo'),
('Heredia', 'Aeropuerto de San Isidro'),
('Cartago', 'Aeropuerto de Cartago'),
('Cartago', 'Aeropuerto de Para�so'),
('Cartago', 'Aeropuerto de Turrialba'),
('Guanacaste', 'Aeropuerto de Liberia'),
('Guanacaste', 'Aeropuerto de Tamarindo'),
('Guanacaste', 'Aeropuerto de Nosara'),
('Puntarenas', 'Aeropuerto de Puntarenas'),
('Puntarenas', 'Aeropuerto de Quepos'),
('Puntarenas', 'Aeropuerto de Golfito'),
('Lim�n', 'Aeropuerto de Lim�n'),
('Lim�n', 'Aeropuerto de Puerto Viejo'),
('Lim�n', 'Aeropuerto de Cahuita');


GO


CREATE TABLE Vuelo(
NumeroVuelo INT PRIMARY KEY,
Capit�n INT, /*Inserted via code*/
Copiloto INT, /*Inserted via code*/
Asistente1 INT, /*Inserted via code*/
Asistente2 INT, /*Inserted via code*/
Partida TINYINT, /*From where the flight starts*/
Destino TINYINT, /*To which province the flight is going*/
FechaVuelo DATE,
HoraVueloSalida TIME,
HoraVueloLlegada TIME,
);


GO


/*The table to manage the seats*/
CREATE TABLE Asientos (
    NumeroVuelo INT,
    NumeroAsiento INT,
	Ocupado VARCHAR(90)
);

GO



/*The very basics to recognize the clients*/
CREATE TABLE Clientes(
CedulaCliente varchar(20) PRIMARY KEY NOT NULL,
NombreCliente VARCHAR(20) NOT NULL,
ApellidoCliente1 VARCHAR(20) NOT NULL,
ApellidoCliente2 VARCHAR(20) NOT NULL,
Telefono VARCHAR(20),
Correo VARCHAR (150),
FechaNacimiento DATETIME,
Sexo CHAR,
);



GO



/*NumTicket is the ID, NumVuelo and NumAsiento are self-explanatory*/
/*Fecha vuelo is used to tell when is the fly. And Hora vuelo does the same but for hours*/
CREATE TABLE Tickets (
    NumTicket INT IDENTITY(1,1),
	CedulaPersona INT,
	NumeroVuelo INT,
	NumeroAsiento TINYINT,
	PesoMaletas SMALLINT,

);



GO



CREATE PROCEDURE MeterCliente
    @Cedula NVARCHAR(50),
    @Nombre NVARCHAR(100),
    @Apell1 NVARCHAR(100),
    @Apell2 NVARCHAR(100)
AS
BEGIN
    -- Example insert operation into a table named 'Persona'
    INSERT INTO Clientes (CedulaCliente, NombreCliente, ApellidoCliente1, ApellidoCliente2)
    VALUES (@Cedula, @Nombre, @Apell1, @Apell2);
END



CREATE PROCEDURE CambiarCliente
    @Cedula NVARCHAR(50),
    @Nombre NVARCHAR(100),
    @Apell1 NVARCHAR(100),
    @Apell2 NVARCHAR(100)
AS
BEGIN
    -- Update the 'Clientes' table for the record with the specified CedulaCliente
    UPDATE Clientes
    SET 
        NombreCliente = @Nombre,
        ApellidoCliente1 = @Apell1,
        ApellidoCliente2 = @Apell2
    WHERE 
        CedulaCliente = @Cedula;
END




CREATE PROCEDURE EliminarCliente
    @Cedula NVARCHAR(50)
AS
BEGIN
    -- Delete the record from the 'Clientes' table with the specified CedulaCliente
    DELETE FROM Clientes
    WHERE CedulaCliente = @Cedula;
END